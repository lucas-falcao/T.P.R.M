﻿using System.ComponentModel.DataAnnotations;

namespace TPRM.Models
{
    public class Cliente
    {
        public int Id { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public int Idade { get; set; }
        [Required]
        public string Cpf { get; set; }
    }
}
