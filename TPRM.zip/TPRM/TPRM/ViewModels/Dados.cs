﻿using Microsoft.AspNetCore.Identity;
using TPRM.Models;
using System.Collections.Generic;

namespace TPRM.ViewModels
{
    public class Dados
    {
        public Cliente Cliente { get; set; }
        public IEnumerable<Cliente> GetAllClientes { get; set; }
        public IEnumerable<IdentityUser> GetAllUsuarios { get; set; }
    }
}
