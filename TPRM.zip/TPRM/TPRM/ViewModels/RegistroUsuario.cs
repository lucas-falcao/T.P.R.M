﻿using System.ComponentModel.DataAnnotations;

namespace TPRM.ViewModels
{
    public class RegistroUsuario
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }


        [Required]
        public string NomeUsuario { get; set; }


        [Required]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirme a Senha")]
        [Compare("Senha", ErrorMessage = "Senha e confirmação da senha não correspondem")]
        public string ConfirmaSenha { get; set; }

    }
}
