﻿using System.ComponentModel.DataAnnotations;

namespace TPRM.ViewModels
{
    public class LoginUsuario
    {
        [Required]
        public string NomeUsuario{ get; set; }


        [Required]
        [DataType(DataType.Password)]
        public string Senha { get; set; }




    }
}
