﻿using Microsoft.AspNetCore.Identity;
using TPRM.Models;
using TPRM.ViewModels;
using System.Collections.Generic;

namespace TPRM.Repository
{
    public interface IRepositorio
    {
        void AdicionaCliente(Cliente cliente);
        Cliente GetCliente(int id);
        void EditaCliente(Cliente cliente);
        void DeletaCliente(int id);
        bool UsuarioExiste(RegistroUsuario dados);
        bool ClienteExiste(Cliente dados);
        IEnumerable<Cliente> GetAllCliente();
        IEnumerable<IdentityUser> GetAllUsuarios();
        IdentityUser GetUsuario(string id);

        
    }
}
