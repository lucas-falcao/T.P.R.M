﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using TPRM.Models;
using TPRM.ViewModels;

namespace TPRM.Repository
{
    public class Repositorio : IRepositorio
    {
        private BancoContext db;

        public Repositorio(BancoContext _db)
        {
            db = _db;
        }
        public void AdicionaCliente(Cliente cliente)
        {
            db.Clientes.Add(cliente);
            db.SaveChanges();
        }

        public Cliente GetCliente(int id)
        {
            var cliente = db.Clientes.Where(c => c.Id == id).FirstOrDefault();
            return cliente;
          
        }

        public void DeletaCliente(int id)
        {
            
            db.Clientes.Remove(GetCliente(id));
            db.SaveChanges();
        }

        public void EditaCliente(Cliente cliente)
        {
            var _cliente = db.Clientes.Where(c => c.Id == cliente.Id).FirstOrDefault();
            _cliente.Nome = cliente.Nome;
            _cliente.Idade = cliente.Idade;
            _cliente.Cpf = cliente.Cpf;
            db.SaveChanges();
        }
        public bool UsuarioExiste(RegistroUsuario usuario)
        {
            if (db.Users.Any(c=>c.UserName == usuario.NomeUsuario))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool ClienteExiste(Cliente cliente)
        {
            if (db.Clientes.Any(c=>c.Cpf == cliente.Cpf))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public IEnumerable<Cliente> GetAllCliente()
        {
            return db.Clientes;
        }
        public IEnumerable<IdentityUser> GetAllUsuarios()
        {
            return db.Users;
        }
        public IdentityUser GetUsuario(string id) 
        {
            var usuario = db.Users.Where(c => c.Id == id).FirstOrDefault();
            return usuario;
        }
        
    }
}
