﻿using Microsoft.AspNetCore.Mvc;

namespace TPRM.Controllers
{
    public class HomeController : Controller
    {
       
        public IActionResult Index()
        {
            return View();
        }
    }
}
