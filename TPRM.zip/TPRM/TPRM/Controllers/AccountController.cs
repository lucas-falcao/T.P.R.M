﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using TPRM.Repository;
using TPRM.ViewModels;
using System.Threading.Tasks;

namespace TPRM.Controllers
{
    public class AccountController : Controller
    {
        private IRepositorio repositorio;
        private UserManager<IdentityUser> userManager;
        private SignInManager<IdentityUser> loginManager;

        public AccountController(IRepositorio repositorio ,UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager)
        {
            this.repositorio = repositorio;
            this.userManager = userManager;
            this.loginManager = signInManager;

        }

        //---------------- Retorna a página inicial com todos os usuários cadastrados --------------------------------------------------------------//

        public IActionResult Index()
        {
            var dados = new Dados { GetAllUsuarios = repositorio.GetAllUsuarios() };
            return View(dados);
        }


        //------------------Retorna página com formuláro para o cadastro ------------------------------------------------------------------------------//

        [HttpGet]
        public IActionResult Cadastrar()
        {
            return View();
        }


        //------------------ Recebe os dados e valida Nome e compatibilidade da senha para cadastrar ------------------------------------------------------------------------------//

        [HttpPost]
        public async Task<IActionResult> Cadastrar(RegistroUsuario dados)
        {
            //Verifica se os dados recebidos são válidos
            if (ModelState.IsValid)
            {
                //Verifica se já existe um usuário com o nome recebido
                if (repositorio.UsuarioExiste(dados))
                {
                    ModelState.AddModelError("", "Já existe um usuário com esse nome");
                    return View(dados);
                }

                var usuario = new IdentityUser { UserName = dados.NomeUsuario, Email = dados.Email };
                var resultado = await userManager.CreateAsync(usuario, dados.Senha);
                if (resultado.Succeeded)
                {
                    return View("Cadastrado");
                }
                foreach(var erro in resultado.Errors)
                {
                    
                    ModelState.AddModelError("", erro.Description);
                }
            }
            return View(dados);
        }

        //------------------- Retorna página de Login -----------------------------------------------------------------------------//

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        //------------------- Faz o login de acordo com os dados recebidos -------------------------------------------------------------//

        [HttpPost]
        public async Task<IActionResult> Login(LoginUsuario dados)
        {
            //Login do usuário caso os dados sejam válidos
            if (ModelState.IsValid)
            {
                var resultado = await loginManager.PasswordSignInAsync(dados.NomeUsuario, dados.Senha, isPersistent:false, false);
                if (resultado.Succeeded)
                {
                    return RedirectToAction("Index", "Home");
                }
                ModelState.AddModelError("", "Dados invalidos");
            }
            return View(dados);
        }

        //-------------------- Faz logout do usuario autenticado-----------------------------------------------------//

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await loginManager.SignOutAsync();
            return RedirectToAction("index","home");
        }


        //-----------------------Retorna os dados do usuario-----------------------------------------//

        [Authorize]
        public IActionResult Informacoes(string id)
        {
            return View(repositorio.GetUsuario(id));
        }

    }
}
