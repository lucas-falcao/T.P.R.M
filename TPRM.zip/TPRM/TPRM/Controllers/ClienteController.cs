﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TPRM.Models;
using TPRM.Repository;
using TPRM.ViewModels;

namespace TPRM.Controllers
{
    [Authorize]
    public class ClienteController : Controller
    {
        private IRepositorio repositorio;

        public ClienteController(IRepositorio repositorio)
        {
            this.repositorio = repositorio;
        }
        public IActionResult Index()
        {
            var dados = new Dados { GetAllClientes = repositorio.GetAllCliente() };
            return View(dados);
        }

        [HttpGet]
        public IActionResult Cadastrar()
        {
            return View();
        }
        [HttpPost]

        public IActionResult Cadastrar(Dados dados)
        {
            if (repositorio.ClienteExiste(dados.Cliente))
            {
                ModelState.AddModelError("", "Já existe cliente com esse CPF");
                return View(dados);
            }
            var cliente = new Cliente { Cpf = dados.Cliente.Cpf, Nome = dados.Cliente.Nome, Idade = dados.Cliente.Idade };
            repositorio.AdicionaCliente(cliente);
            return RedirectToAction("Index");

        }
        public IActionResult Editar(int id)
        {
            return View(repositorio.GetCliente(id));
        }
        [HttpPost]
        public IActionResult Editar(Cliente dados)
        {
            repositorio.EditaCliente(dados);
            return View("Consultar",dados);
        }
      
        public IActionResult Consultar(int id) 
        {
            var cliente = repositorio.GetCliente(id);
            return View(cliente);
        }

        
        public IActionResult Excluir(int id)
        {
            repositorio.DeletaCliente(id);
            return RedirectToAction("Index");
        }

    }
}
